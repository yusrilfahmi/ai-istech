"""
Text-only PDF -> Markdown parser.
-------------------------
modul ini menggunakan PyMuPDF (fitz) untuk mengekstrak teks dari PDF dan mengubahnya menjadi Markdown dengan heading-aware.
Heading ditentukan berdasarkan ukuran font, dengan asumsi bahwa heading memiliki ukuran font yang lebih besar daripada teks biasa.

Fungsi:
- parse_pdf_to_markdown: menerima path ke file PDF, mengekstrak teks, dan mengembalikannya sebagai string Markdown.

"""

import pymupdf as fitz 
H1_MIN_SIZE = 18
H2_MIN_SIZE = 14
H3_MIN_SIZE = 12

def parse_pdf_to_markdown(path: str) -> str:
    doc = fitz.open(path)
    try:
        markdown_parts = []
        for page in doc:
            blocks = page.get_text("dict")["blocks"]
            for block in blocks:
                if block["type"] != 0:
                    continue
                for line in block["lines"]:
                    line_text = " ".join(span["text"] for span in line["spans"]).strip()
                    if not line_text:
                        continue
                    max_size = max(span["size"] for span in line["spans"])
                    if max_size >= H1_MIN_SIZE:
                        markdown_parts.append(f"# {line_text}")
                    elif max_size >= H2_MIN_SIZE:
                        markdown_parts.append(f"## {line_text}")
                    elif max_size >= H3_MIN_SIZE:
                        markdown_parts.append(f"### {line_text}")
                    else:
                        markdown_parts.append(line_text)
        return "\n".join(markdown_parts)
    finally:
        doc.close()
