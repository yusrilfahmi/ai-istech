"""
Embeddings-chunks
---------------
Catatan:
- Model embedding default adalah "sentence-transformers/all-mpnet-base-v2",
        tetapi dapat dikonfigurasi melalui variabel lingkungan EMBEDDING_MODEL_NAME.
- Server Ollama dapat digunakan sebagai alternatif untuk menghasilkan embedding,
        dengan mengatur variabel lingkungan OLLAMA_SERVER_URL ke URL server Ollama yang sesuai.
- Dimensi embedding default adalah 768, tetapi dapat bervariasi tergantung pada model yang digunakan.
        dan harus seragam dalam 1 tabel vector database.

"""

import os
from functools import lru_cache
from typing import List

from langchain_huggingface import HuggingFaceEmbeddings
from langchain_ollama import OllamaEmbeddings

EMBEDDING_MODEL_NAME = os.getenv("EMBEDDING_MODEL_NAME", "sentence-transformers/all-mpnet-base-v2")
OLLAMA_BASE_URL = os.getenv("OLLAMA_SERVER_URL", "http://10.10.10.5:11434") 

## Kalau pakai HuggingFaceEmbeddings via API
@lru_cache(maxsize=1)
def get_embedder() -> HuggingFaceEmbeddings:
    return HuggingFaceEmbeddings(
        model_name=EMBEDDING_MODEL_NAME,
        model_kwargs={"device": "cpu"},
    )

## Kalau pakai OllamaEmbeddings via Ollama Server
# @lru_cache(maxsize=1)
# def get_embedder() -> OllamaEmbeddings:
#     """Initialize the Ollama embedding connection once per process."""
#     return OllamaEmbeddings(
#         model=EMBEDDING_MODEL_NAME,
#         base_url=OLLAMA_BASE_URL
#     )


def embed_texts(texts: List[str]) -> List[List[float]]:
    if not texts:
        return []
    return get_embedder().embed_documents(texts)
