# """
# Vector store (PGVector) helpers: insert new chunks, delete existing ones by
# file name.

# """

# import os
# import uuid
# from functools import lru_cache
# from typing import List

# from langchain_core.documents import Document
# from langchain_postgres.vectorstores import PGVector

# from embedding import get_embedder

# CONNECTION_STRING = os.getenv("CONNECTION_STRING")
# COLLECTION_NAME = os.getenv("VECTOR_COLLECTION_NAME", "documents_header")


# @lru_cache(maxsize=1)
# def get_store() -> PGVector:
#     if not CONNECTION_STRING:
#         raise RuntimeError(
#             "CONNECTION_STRING environment variable is not set. "
#             "Point it at your Postgres+pgvector instance (see .env.example)."
#         )
#     return PGVector(
#         embeddings=get_embedder(),
#         collection_name=COLLECTION_NAME,
#         connection=CONNECTION_STRING,
#         use_jsonb=True,
#     )


# def _ids_for(file_name: str, count: int) -> List[str]:
#     return [str(uuid.uuid5(uuid.NAMESPACE_DNS, f"{file_name}_chunk_{i}")) for i in range(count)]


# def add_chunks(chunks: List[Document], file_name: str) -> List[str]:
#     """Embed + insert chunks into the vector store. Returns the ids used."""
#     if not chunks:
#         return []
#     ids = _ids_for(file_name, len(chunks))
#     get_store().add_documents(chunks, ids=ids)
#     return ids


# def delete_by_file_name(file_name: str) -> int:
#     """Delete all stored chunks belonging to a file name. Returns how many were deleted."""
#     store = get_store()
#     existing = store.similarity_search("", k=10000, filter={"file_name": file_name})
#     if not existing:
#         return 0
#     ids = _ids_for(file_name, len(existing))
#     store.delete(ids=ids)
#     return len(ids)
