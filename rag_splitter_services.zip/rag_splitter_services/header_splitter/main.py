"""
header-splitter service
------------------------
Text-only PDF parsing + header-based chunking (per bab/sub-bab), di ekspos
melalui FastAPI endpoints. 

Endpoints:
  POST   /chunk -> parse, chunk, embed, dan (by default) menyimpan PDF;
                   returns {doc_id, file_name, chunks[]}
                   dimana setiap chunk berisi {pageContent, embeddings, metadata}.
  DELETE /knowledgebase/{file_name}  -> delete semua chunks yang terkait berdasarkan file_name dari vector store.
  GET    /health 
   
"""

import os
import shutil
import tempfile
import uuid
from typing import List, Optional

import requests
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from pydantic import BaseModel

from chunker import chunk_markdown
from embedding import embed_texts
from parser import parse_pdf_to_markdown
# from store import add_chunks, delete_by_file_name

app = FastAPI(title="header-splitter", version="1.0.0")


class ChunkResult(BaseModel):
    pageContent: str
    embeddings: List[float]
    metadata: dict


class ChunkResponse(BaseModel):
    doc_id: str
    file_name: str
    chunk_count: int
    chunks: List[ChunkResult]


class DeleteResponse(BaseModel):
    file_name: str
    deleted_count: int


def _download_from_url(url: str) -> str:
    response = requests.get(url, timeout=120)
    response.raise_for_status()
    with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
        tmp.write(response.content)
        return tmp.name


@app.post("/chunk", response_model=ChunkResponse)
async def chunk_document(
    file: Optional[UploadFile] = File(
        None, description="PDF file, sent as multipart/form-data (e.g. from n8n's binary data)."
    ),
    local_path: Optional[str] = Form(
        None, description="Path to a PDF already reachable inside this container, e.g. a mounted local folder."
    ),
    source_url: Optional[str] = Form(
        None, description="Alternative to 'file'/'local_path': an http(s):// URL to download the PDF from."
    ),
    doc_id: Optional[str] = Form(None, description="Optional stable id for this document."),
    file_name: Optional[str] = Form(None, description="Optional display name; defaults to the uploaded/local filename."),
):
    if not file and not local_path and not source_url:
        raise HTTPException(status_code=400, detail="Provide one of 'file', 'local_path', or 'source_url'.")

    tmp_path = None
    should_cleanup = False
    resolved_file_name = (
        file_name
        or (file.filename if file else None)
        or (os.path.basename(local_path) if local_path else None)
        or "document.pdf"
    )
    resolved_doc_id = doc_id or str(uuid.uuid4())

    try:
        if file:
            with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
                shutil.copyfileobj(file.file, tmp)
                tmp_path = tmp.name
            should_cleanup = True
        elif local_path:
            if not os.path.isfile(local_path):
                raise HTTPException(
                    status_code=400,
                    detail=f"local_path not found inside the container: {local_path}. "
                    "Check your volume mount in docker-compose.yml.",
                )
            tmp_path = local_path
            should_cleanup = False
        elif source_url.startswith("http://") or source_url.startswith("https://"):
            tmp_path = _download_from_url(source_url)
            should_cleanup = True
        else:
            raise HTTPException(
                status_code=400,
                detail="source_url must start with http:// or https:// (use 'local_path' for local files).",
            )

        markdown_content = parse_pdf_to_markdown(tmp_path)
        docs = chunk_markdown(markdown_content, resolved_file_name, resolved_doc_id)
        vectors = embed_texts([d.page_content for d in docs])

        return ChunkResponse(
            doc_id=resolved_doc_id,
            file_name=resolved_file_name,
            chunk_count=len(docs),
            chunks=[
                ChunkResult(pageContent=d.page_content, embeddings=vec, metadata=d.metadata)
                for d, vec in zip(docs, vectors)
            ],
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail={"error_code": "CHUNK_FAILED", "message": str(e)})
    finally:
        if tmp_path and should_cleanup and os.path.exists(tmp_path):
            os.unlink(tmp_path)


# @app.delete("/knowledgebase/{file_name}", response_model=DeleteResponse)
# async def delete_knowledgebase(file_name: str):
#     try:
#         # deleted = delete_by_file_name(file_name)
#         return DeleteResponse(file_name=file_name, deleted_count=deleted)
#     except Exception as e:  # noqa: BLE001
#         raise HTTPException(status_code=500, detail={"error_code": "DELETE_FAILED", "message": str(e)})


@app.get("/health")
async def health():
    return {"status": "ok", "service": "header-splitter"}
