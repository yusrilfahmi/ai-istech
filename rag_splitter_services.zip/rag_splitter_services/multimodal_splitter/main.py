"""
main.py
----------------------------
Parsing PDF multimodal (teks + OCR + deskripsi gambar/tabel) + pemecahan (chunking)
berbasis header (per bab/sub-bab), yang disajikan sebagai layanan FastAPI agar dapat
dipanggil dari node HTTP Request n8n.

Endpoints:
  POST /chunk                        -> parse + chunk a PDF, returns {doc_id, file_name, chunks[]}
  GET  /images/{doc_id}/{filename}   -> ekstrak gambar dari PDF, menyimpannya di storage lokal, dan mengembalikan URL untuk diakses.
  GET  /health                       -> returns {"status": "ok", "service": "multimodal-splitter"}

Catatan:
Masih dalam tahap pengembangan (urung di test)

"""

import os
import shutil
import tempfile
import uuid
from typing import List, Optional

import requests
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from chunker import chunk_markdown
from parser import STORAGE_DIR, parse_pdf_to_markdown

app = FastAPI(title="multimodal-splitter", version="1.0.0")

STORAGE_DIR.mkdir(parents=True, exist_ok=True)
app.mount("/images", StaticFiles(directory=str(STORAGE_DIR)), name="images")


class ChunkResult(BaseModel):
    pageContent: str
    metadata: dict


class ChunkResponse(BaseModel):
    doc_id: str
    file_name: str
    chunk_count: int
    chunks: List[ChunkResult]


def _download_from_url(url: str) -> str:
    response = requests.get(url, timeout=120)
    response.raise_for_status()
    with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
        tmp.write(response.content)
        return tmp.name


@app.post("/chunk", response_model=ChunkResponse)
async def chunk_document(
    file: Optional[UploadFile] = File(
        None, description="PDF file, sent as multipart/form-data (e.g. from n8n's binary data)."
    ),
    local_path: Optional[str] = Form(
        None, description="Path to a PDF already reachable inside this container, e.g. a mounted local folder."
    ),
    source_url: Optional[str] = Form(
        None, description="Alternative to 'file'/'local_path': an http(s):// URL to download the PDF from."
    ),
    doc_id: Optional[str] = Form(None, description="Optional stable id for this document."),
    file_name: Optional[str] = Form(None, description="Optional display name; defaults to the uploaded/local filename."),
):
    if not file and not local_path and not source_url:
        raise HTTPException(status_code=400, detail="Provide one of 'file', 'local_path', or 'source_url'.")

    tmp_path = None
    should_cleanup = False
    resolved_file_name = (
        file_name
        or (file.filename if file else None)
        or (os.path.basename(local_path) if local_path else None)
        or "document.pdf"
    )
    resolved_doc_id = doc_id or str(uuid.uuid4())

    try:
        if file:
            with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
                shutil.copyfileobj(file.file, tmp)
                tmp_path = tmp.name
            should_cleanup = True
        elif local_path:
            if not os.path.isfile(local_path):
                raise HTTPException(
                    status_code=400,
                    detail=f"local_path not found inside the container: {local_path}. "
                    "Check your volume mount in docker-compose.yml.",
                )
            tmp_path = local_path
            should_cleanup = False
        elif source_url.startswith("http://") or source_url.startswith("https://"):
            tmp_path = _download_from_url(source_url)
            should_cleanup = True
        else:
            raise HTTPException(
                status_code=400,
                detail="source_url must start with http:// or https:// (use 'local_path' for local files).",
            )

        markdown_content = parse_pdf_to_markdown(tmp_path, resolved_doc_id)
        docs = chunk_markdown(markdown_content, resolved_file_name, resolved_doc_id)

        return ChunkResponse(
            doc_id=resolved_doc_id,
            file_name=resolved_file_name,
            chunk_count=len(docs),
            chunks=[ChunkResult(pageContent=d.page_content, metadata=d.metadata) for d in docs],
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail={"error_code": "CHUNK_FAILED", "message": str(e)})
    finally:
        if tmp_path and should_cleanup and os.path.exists(tmp_path):
            os.unlink(tmp_path)


@app.get("/health")
async def health():
    return {"status": "ok", "service": "multimodal-splitter"}
