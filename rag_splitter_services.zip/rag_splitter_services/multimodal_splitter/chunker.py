"""
chunker.py
-------------------------
Menyediakan fungsi untuk memecah konten Markdown menjadi potongan-potongan yang lebih kecil (chunks)
berdasarkan header (bab/sub-bab), dan menggabungkan potongan-potongan kecil dengan potongan
sebelumnya jika mereka berada di bawah header yang sama.

Fungsi:
-   chunk_markdown: Fungsi utama untuk melakukan chunking pada konten Markdown,
    mengembalikan daftar Document siap untuk di-embed.

"""

import re
from typing import List

from langchain_core.documents import Document
from langchain_text_splitters import MarkdownHeaderTextSplitter

MIN_CHUNK_CHARS = 200
_IMAGE_URL_PATTERN = re.compile(r"!\[[^\]]*\]\(([^)]+)\)")


def _extract_image_urls(text: str) -> List[str]:
    return _IMAGE_URL_PATTERN.findall(text)


def chunk_markdown(markdown_content: str, file_name: str, doc_id: str) -> List[Document]:
    splitter = MarkdownHeaderTextSplitter(
        headers_to_split_on=[
            ("#", "Header_1"),
            ("##", "Header_2"),
            ("###", "Header_3"),
        ],
    )
    raw_chunks = splitter.split_text(markdown_content)

    merged: List[Document] = []
    for doc in raw_chunks:
        is_header_1_only = (
            doc.metadata.get("Header_1") is not None
            and doc.metadata.get("Header_2") is None
            and doc.metadata.get("Header_3") is None
        )
        is_small = len(doc.page_content.strip()) < MIN_CHUNK_CHARS

        if merged and is_small and not is_header_1_only:
            prev = merged[-1]
            if prev.metadata.get("Header_1") == doc.metadata.get("Header_1"):
                section_title = (
                    doc.metadata.get("Header_3")
                    or doc.metadata.get("Header_2")
                    or ""
                )
                prefix = f"\n{section_title}\n" if section_title else "\n"
                prev.page_content += prefix + doc.page_content
            else:
                merged.append(doc)
        else:
            merged.append(doc)

    documents: List[Document] = []
    for i, chunk in enumerate(merged):
        header_parts = [
            h
            for h in [
                chunk.metadata.get("Header_1"),
                chunk.metadata.get("Header_2"),
                chunk.metadata.get("Header_3"),
            ]
            if h
        ]
        metadata = {
            "doc_id": doc_id,
            "file_name": file_name,
            "chunk_id": i,
            "header": "/".join(header_parts),
        }
        image_urls = _extract_image_urls(chunk.page_content)
        if image_urls:
            metadata["image_urls"] = image_urls

        documents.append(Document(page_content=chunk.page_content, metadata=metadata))
    return documents
