"""
Multimodal PDF -> Markdown parser (Docling-based).

"""

import base64
import os
from contextvars import ContextVar
from io import BytesIO
from pathlib import Path
from typing import Any, Optional

import requests
from typing_extensions import override

from docling.datamodel.base_models import InputFormat
from docling.datamodel.pipeline_options import PdfPipelineOptions
from docling.document_converter import DocumentConverter, PdfFormatOption
from docling_core.transforms.serializer.base import BaseDocSerializer, SerializationResult
from docling_core.transforms.serializer.common import create_ser_result
from docling_core.transforms.serializer.markdown import (
    MarkdownDocSerializer,
    MarkdownParams,
    MarkdownPictureSerializer,
    MarkdownTableSerializer,
)
from docling_core.types.doc import DoclingDocument, ImageRefMode, PictureItem, TableItem

STORAGE_DIR = Path(os.getenv("IMAGE_STORAGE_DIR", "/app/storage/images"))
IMAGE_BASE_URL = os.getenv("IMAGE_BASE_URL", "http://localhost:8002/images").rstrip("/")

DESCRIPTION_API_URL = os.getenv("DESCRIPTION_API_URL", "")
DESCRIPTION_MODEL = os.getenv("DESCRIPTION_MODEL", "gemma4:e4b")
DESCRIBE_TABLES = os.getenv("DESCRIBE_TABLES", "true").lower() == "true"
DESCRIBE_PICTURES = os.getenv("DESCRIBE_PICTURES", "true").lower() == "true"

_current_doc_id: ContextVar[str] = ContextVar("current_doc_id", default="_")

_pipeline_options = PdfPipelineOptions()
_pipeline_options.do_ocr = True
_pipeline_options.generate_picture_images = True
_pipeline_options.images_scale = 2.0

_converter = DocumentConverter(
    format_options={InputFormat.PDF: PdfFormatOption(pipeline_options=_pipeline_options)}
)

def _save_image(pil_image, item_ref: str) -> Optional[str]:
    try:
        doc_id = _current_doc_id.get()
        doc_dir = STORAGE_DIR / doc_id
        doc_dir.mkdir(parents=True, exist_ok=True)
        safe_id = item_ref.replace("/", "_").replace("#", "")
        filename = f"{safe_id}.png"
        with (doc_dir / filename).open("wb") as fp:
            pil_image.save(fp, format="PNG")
        return f"{IMAGE_BASE_URL}/{doc_id}/{filename}"
    except Exception:
        return None


def _describe_image(pil_image) -> str:
    if not DESCRIPTION_API_URL:
        return ""
    try:
        buf = BytesIO()
        pil_image.save(buf, format="PNG")
        b64 = base64.b64encode(buf.getvalue()).decode("utf-8")

        resp = requests.post(
            DESCRIPTION_API_URL,
            json={
                "model": DESCRIPTION_MODEL,
                "messages": [
                    {
                        "role": "user",
                        "content": [
                            {
                                "type": "text",
                                "text": (
                                    "Describe this image or table in detail, in the "
                                    "context of a technical manual. Be specific about "
                                    "any labels, values, or steps shown."
                                ),
                            },
                            {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{b64}"}},
                        ],
                    }
                ],
                "max_tokens": 300,
            },
            timeout=60,
        )
        resp.raise_for_status()
        return resp.json()["choices"][0]["message"]["content"].strip()
    except Exception:
        return ""

class StorageAwarePictureSerializer(MarkdownPictureSerializer):
    @override
    def serialize(
        self,
        *,
        item: PictureItem,
        doc_serializer: BaseDocSerializer,
        doc: DoclingDocument,
        separator: Optional[str] = None,
        **kwargs: Any,
    ) -> SerializationResult:
        parts = []
        pil_image = None
        try:
            pil_image = item.get_image(doc)
        except Exception:
            pil_image = None

        if pil_image is not None:
            url = _save_image(pil_image, item.self_ref)
            description = _describe_image(pil_image) if DESCRIBE_PICTURES else ""
            if url:
                caption = description[:80] if description else "image"
                parts.append(f"![{caption}]({url})")
            if description:
                parts.append(f"<!-- Picture description: {description} -->")

        if not parts:
            parts.append("<!-- image (unavailable) -->")

        text = (separator or "\n").join(parts)
        return create_ser_result(text=text, span_source=item)


class StorageAwareTableSerializer(MarkdownTableSerializer):
    @override
    def serialize(
        self,
        *,
        item: TableItem,
        doc_serializer: BaseDocSerializer,
        doc: DoclingDocument,
        separator: Optional[str] = None,
        **kwargs: Any,
    ) -> SerializationResult:
        base_result = super().serialize(item=item, doc_serializer=doc_serializer, doc=doc, **kwargs)
        parts = [base_result.text]

        if DESCRIBE_TABLES:
            try:
                pil_image = item.get_image(doc)
            except Exception:
                pil_image = None
            if pil_image is not None:
                description = _describe_image(pil_image)
                if description:
                    parts.append(f"<!-- Table description: {description} -->")

        text = (separator or "\n").join(parts)
        return create_ser_result(text=text, span_source=item)

def parse_pdf_to_markdown(path: str, doc_id: str) -> str:
    token = _current_doc_id.set(doc_id)
    try:
        result = _converter.convert(path)
        doc = result.document
        serializer = MarkdownDocSerializer(
            doc=doc,
            picture_serializer=StorageAwarePictureSerializer(),
            table_serializer=StorageAwareTableSerializer(),
            params=MarkdownParams(
                image_mode=ImageRefMode.PLACEHOLDER,
                image_placeholder="",
            ),
        )
        return serializer.serialize().text
    finally:
        _current_doc_id.reset(token)
