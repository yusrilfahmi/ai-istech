# RAG Splitter Services

Repository ini berisi dua layanan parsing PDF yang dikembangkan untuk memisahkan tugas chunking dokumen dari proses embedding dan penyimpanan vektor di workflow n8n. Setiap layanan menerima PDF, memprosesnya, lalu mengembalikan daftar chunk siap dipakai oleh pipeline embedding selanjutnya.

## Tujuan

- Menyediakan endpoint HTTP untuk memecah PDF menjadi chunk yang rapi.
- Mengurangi beban kerja di n8n dan memisahkan proses parsing/chunking menjadi service terpisah.
- Mendukung dua pendekatan:
  - `header_splitter`: parsing teks berdasarkan heading/layout dokumen
  - `multimodal_splitter`: parsing PDF multimodal yang juga menangani gambar dan tabel

## Struktur proyek

```text
rag_splitter_services/
├── README.md
├── requirements.txt
├── docker-compose.yml          # opsional kalau ingin di jalankan di server docker
├── header_splitter/
│   ├── chunker.py
│   ├── embedding.py
│   ├── main.py
│   └── parser.py
├── multimodal_splitter/
│   ├── chunker.py
│   ├── main.py
│   └── parser.py
└── documents/                  # folder opsional untuk file PDF lokal
```

## Layanan yang tersedia

### 1. header_splitter
Layanan ini fokus pada dokumen teks berbasis PDF. Ia mengekstrak isi PDF, mengubah heading menjadi markdown, lalu membagi dokumen menurut struktur heading.

Fungsi utama:
- parsing PDF menggunakan PyMuPDF
- deteksi heading berdasarkan ukuran font
- chunking berdasarkan struktur header
- menghasilkan embedding teks menggunakan model embedding yang sudah dikonfigurasi

Endpoint utama:
- `POST /chunk`
- `GET /health`

### 2. multimodal_splitter
Layanan ini ditujukan untuk dokumen PDF yang memiliki komponen visual seperti gambar, diagram, atau tabel. Ia memanfaatkan Docling untuk menghasilkan markdown yang mempertahankan informasi visual, serta menyimpan gambar yang terekstraksi agar bisa ditautkan di respons chunk.

Fungsi utama:
- OCR pada PDF
- ekstraksi gambar dan tabel
- pembuatan markdown multimodal
- penyimpanan gambar lokal dan tautan URL di metadata

Endpoint utama:
- `POST /chunk`
- `GET /images/{doc_id}/{filename}`
- `GET /health`

## Prasyarat

- Python 3.11
- dependency yang terdaftar di `requirements.txt`
- akses ke model embedding yang ingin dipakai, baik melalui Hugging Face maupun Ollama

## Instalasi lokal

```bash
cd d:\Programming\rag_splitter_services
python -m venv .venv
.\.venv\Scripts\activate
pip install -r requirements.txt
```

## Menjalankan service

### Mode lokal tanpa Docker

```bash
cd header_splitter
uvicorn main:app --host 0.0.0.0 --port 8001 --reload
```

```bash
cd multimodal_splitter
uvicorn main:app --host 0.0.0.0 --port 8002 --reload
```

### Mode container

File `docker-compose.yml` sudah tersedia di root project untuk menjalankan layanan secara bersamaan.

```bash
docker compose up --build
```

## Endpoint API

### `POST /chunk`

Request menggunakan `multipart/form-data`. Minimal salah satu field harus dikirim:

- `file`: file PDF langsung dari upload
- `local_path`: path file PDF yang bisa diakses dari container atau mesin lokal
- `source_url`: URL PDF yang akan diunduh otomatis

Field opsional:

- `doc_id`: ID dokumen yang stabil
- `file_name`: nama tampilan dokumen

Contoh request dengan file upload:

```bash
curl -X POST "http://localhost:8001/chunk" \
  -F "file=@manual.pdf" \
  -F "doc_id=manual-001" \
  -F "file_name=Manual.pdf"
```

Contoh respons:

```json
{
  "doc_id": "manual-001",
  "file_name": "Manual.pdf",
  "chunk_count": 6,
  "chunks": [
    {
      "pageContent": "# Pendahuluan\n\nDokumen ini menjelaskan prosedur...",
      "metadata": {
        "doc_id": "manual-001",
        "file_name": "Manual.pdf",
        "chunk_id": 0,
        "header": "Pendahuluan"
      }
    }
  ]
}
```

Pada `multimodal_splitter`, metadata juga bisa berisi tautan gambar jika dokumen mengandung ilustrasi atau tabel yang berhasil diolah.

### `GET /health`

Mengembalikan status kesehatan service.

Contoh respons:

```json
{
  "status": "ok",
  "service": "header-splitter"
}
```

### `GET /images/{doc_id}/{filename}`

Hanya tersedia di `multimodal_splitter`. Endpoint ini menampilkan gambar yang sudah diekstrak dari PDF, sehingga URL di metadata dapat diakses kembali oleh aplikasi atau workflow downstream.

## Penggunaan dari n8n

1. Gunakan node HTTP Request untuk melakukan `POST` ke endpoint `/chunk`.
2. Kirim file PDF sebagai form-data.
3. Ambil field `chunks` dari response.
4. Mapping hasil ke struktur JSON yang dipakai oleh node berikutnya, misalnya embedding atau vector store.

Secara praktis, hasil chunk sudah berbentuk:

```json
{
  "pageContent": "...",
  "metadata": {
    "doc_id": "...",
    "file_name": "...",
    "chunk_id": 0,
    "header": "..."
  }
}
```

Jadi, pipeline n8n bisa langsung memanfaatkan hasil tanpa perlu splitter tambahan.

## Konfigurasi embedding

Model embedding dapat diatur melalui variabel lingkungan, misalnya `EMBEDDING_MODEL_NAME`. File `header_splitter/embedding.py` mendukung dua pendekatan:

- Hugging Face embeddings
- Ollama embeddings

Untuk Ollama, aktifkan bagian kode yang sesuai dan atur endpoint server yang dipakai.

## Catatan penting

- `header_splitter` cocok untuk dokumen teks yang struktur heading-nya jelas.
- `multimodal_splitter` lebih cocok untuk PDF yang mengandung gambar, diagram, atau tabel.
- Kecepatan dan kualitas hasil bergantung pada model embedding dan kemampuan OCR/parser dokumen yang dipakai.
- Jika ingin menggunakan versi embedding/ocr yang berbeda, pastikan dimensi output embedding konsisten di seluruh pipeline vector database.

## Lisensi

Project ini dibuat untuk kebutuhan internal workflow RAG dan dapat disesuaikan sesuai kebutuhan deployment masing-masing tim.
